JARVIS 7.0.1 TEST UPDATE

Upload these two files to the root of your GitHub JARVIS_UPDATES main branch:
- updater.manifest.json
- data/update_test_7_0_1.txt

SHA-256:
c161a02dcbdeef752d741e98e5ea128ebc6942177dcb871eb7ed137cdd1795ed

Then run JARVIS. It should detect 7.0.1 and install the test file.
Check G:\Jarvis_v6\data\update_test_7_0_1.txt

Do not replace jarvis.py or updater.py for this test.
